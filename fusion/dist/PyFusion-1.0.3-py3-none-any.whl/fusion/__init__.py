"""Top-level package for fusion."""

__author__ = """Fusion Devs"""
__email__ = 'fusion_developers@jpmorgan.com'
__version__ = '1.0.3'

from fusion.fusion import Fusion
